package projectOne;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {
    @Test
    public void testContactProperties() {
        Contact contact = new Contact("John", "Doe", "1234567890", "123 Main St");
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main St", contact.getAddress());
    }

    @Test
    public void testInvalidFirstName() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> new Contact(null, "Doe", "1234567890", "123 Main St"));
        assertEquals("Invalid first name", exception.getMessage());
    }

    @Test
    public void testValidContactId() {
        Contact contact = new Contact("John", "Doe", "1234567890", "123 Main St");
        contact.validateContactId();
    }

    @Test
    public void testInvalidLastName() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> new Contact("John", null, "1234567890", "123 Main St"));
        assertEquals("Invalid last name", exception.getMessage());
    }

    @Test
    public void testInvalidPhone() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> new Contact("John", "Doe", null, "123 Main St"));
        assertEquals("Invalid phone number", exception.getMessage());
    }

    @Test
    public void testInvalidAddress() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> new Contact("John", "Doe", "1234567890", null));
        assertEquals("Invalid address", exception.getMessage());
    }
    @Test
    public void testValidContact(){
        Contact contact = new Contact("John", "Doe", "1234567890", "123 Main St");
        assertNotNull(contact);
    }

    @Test
    void testSetLastName() {
        Contact contact = new Contact("John", "Doe", "1234567890", "123 Main St");
        contact.setLastName("Smith");
        assertEquals("Smith", contact.getLastName());
    }

    @Test
    void testGetPhone() {
        Contact contact = new Contact("John", "Doe", "1234567890", "123 Main St");
        assertEquals("1234567890", contact.getPhone());
    }

    @Test
    void testSetPhone() {
        Contact contact = new Contact("John", "Doe", "1234567890", "123 Main St");
        contact.setPhone("1234567890");
        assertEquals("1234567890", contact.getPhone());
    }

    @Test
    void testGetAddress() {
        Contact contact = new Contact("John", "Doe", "1234567890", "123 Main St");
        assertEquals("123 Main St", contact.getAddress());
    }

    @Test
    void testSetAddress() {
        Contact contact = new Contact("John", "Doe", "1234567890", "123 Main St");
        contact.setAddress("456 Main St");
        assertEquals("456 Main St", contact.getAddress());
    }


}