package projectOne;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {
    private ContactService contactService;

    @BeforeEach
    public void setUp() {
        contactService = new ContactService();
    }

    @Test
    public void testAddContact() {
        Contact contact = new Contact("John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertEquals(contact, contactService.getContact(contact.getContactId()));
    }



    @Test
    public void testUpdateContact() {
        Contact contact1 = new Contact("John", "Doe", "1234567890", "123 Main St");
        Contact contact2 = new Contact("Jane", "Smith", "0987654321", "456 Park Ave");
        contactService.addContact(contact1);
        contactService.updateContact(contact1.getContactId(), contact2);
        assertEquals(contact2, contactService.getContact(contact1.getContactId()));
    }

    @Test
    public void testUpdateContact_InvalidId() {
        Contact contact = new Contact("John", "Doe", "1234567890", "123 Main St");
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateContact("invalidId", contact);
        });
        assertEquals("Contact not found", exception.getMessage());
    }

    @Test
    public void testRemoveContact() {
        Contact contact = new Contact("John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        contactService.removeContact(contact.getContactId());
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            contactService.getContact(contact.getContactId());
        });
        assertEquals("Contact not found", exception.getMessage());
    }

    @Test
    public void testRemoveContact_InvalidId() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            contactService.removeContact("invalidId");
        });
        assertEquals("Contact not found", exception.getMessage());
    }

}